import pickle


# pickle 序列化和反序列化
# d = dict(name='hai', age=28)
# p = pickle.dumps(d)
# print(p)
# print(pickle.loads(p))
# 序列化对象写入文件
# with open('02.txt', 'wb') as f:
    # pickle.dump(d, f)

# 从文件读取内容为序列化对象
# with open('02.txt', 'rb') as f:
    # p = pickle.load(f)
    # print(p)


import json
